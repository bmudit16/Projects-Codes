package com.bss.videoCall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideoCallApplicationTests {

	@Test
	void contextLoads() {
	}

}
